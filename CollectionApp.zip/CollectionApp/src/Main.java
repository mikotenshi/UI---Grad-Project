

import SlidingLibrary.SLAnimator;
import aurelienribon.tweenengine.Tween;

public class Main {

    public static void main(String[] args) {

        Tween.registerAccessor(SidebarPanel.class, new SidebarPanel.Accessor());
        SLAnimator.start();

        CollectionFrame frame = new CollectionFrame();

        frame.setVisible(true);
    }

}
