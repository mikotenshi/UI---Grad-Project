
import SlidingLibrary.SLSide;
import SlidingLibrary.SLKeyframe;
import SlidingLibrary.SLConfig;
import SlidingLibrary.SLAnimator;
import SlidingLibrary.SLPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.io.IOException;

/**
 * 
 * Created by newuser on 10/20/16.
 * 
 */
public class CollectionFrame extends JFrame {

//    SidebarPanel menu
    private SidebarPanel sidebarPanel = new SidebarPanel();
    private BookShelf bookshelf;
    private TagPhotoPanel tagPhotoPanel = new TagPhotoPanel();
//   for file menu
    private final SLPanel panel = new SLPanel();
    private final SLConfig mainCfg;
    private final SLConfig p1Cfg;
    private final SLConfig taggedPhotoConfig;
    private ImageIcon menu = new ImageIcon(getClass().getResource("/myimages/menu.png"));
    private ImageIcon addButton = new ImageIcon(getClass().getResource("/myimages/add.png"));
//    Toggles menu on/off screen
    private boolean isSideBarOnScreen = true;
    private boolean isTagBarOnScreen = true;
    private JToolBar toolbar = new JToolBar();
    
    public ArrayList<Object> list;

    public CollectionFrame() throws IOException {
        this.bookshelf = new BookShelf();
        list = new ArrayList<Object>();
        
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(500, 500));

        setUpToolBar();

//        Handle Collection Frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel.setPreferredSize(new Dimension(800, 600));
        panel.setOpaque(true);
        panel.setBackground(Color.white);
        sidebarPanel.setAction(p1Action);

//        Side side bar to the left of the frame
        panel.add(sidebarPanel);

//        configure main panel
        mainCfg = new SLConfig(panel)
                .gap(10, 10)
                .row(2f).col(100).col(2f)
                .place(0, 0, sidebarPanel)
                .place(0, 1, bookshelf);
//configure sidebar panel in main panel
        p1Cfg = new SLConfig(panel)
                .gap(10, 10) //gap between blocks when clicked
                .row(1f).col(1f)
                .place(0, 0, bookshelf);
        
        taggedPhotoConfig  = new SLConfig(panel)
			.gap(10, 10)
                        .row(3f).row(100).col(1f)
                        .beginGrid(0,0)
                        .row(2f).col(100).col(2f)
                            .place(0, 0, sidebarPanel)
                            .place(0, 1, bookshelf)
                        .endGrid()
                        .beginGrid(1, 0)
                            .row(2f).col(1f)
                            .place(0,0,tagPhotoPanel)
                        .endGrid();

        panel.setTweenManager(SLAnimator.createTweenManager());
        panel.initialize(mainCfg);
        add(panel);

//        add the shelf to the frame
//        add(shelf, BorderLayout.CENTER);
    }

//    Hide side Panel. Side bar panel slides to the left 
    private final Runnable p1Action = new Runnable() {
        @Override
        public void run() {
            disableActions();

            panel.createTransition()
                    .push(new SLKeyframe(p1Cfg, 1f)
                            .setEndSide(SLSide.LEFT, sidebarPanel)
                            .setCallback(() -> {
                                sidebarPanel.setAction(p1BackAction);
                                sidebarPanel.enableAction();
            })).play();
            
        }
    };

//THis action slide the sidebar panel back onto the screen 
    private final Runnable p1BackAction = new Runnable() {
        @Override
        public void run() {
            disableActions();

            panel.createTransition()
                    .push(new SLKeyframe(mainCfg, 0.6f)
                            .setStartSide(SLSide.RIGHT, sidebarPanel)
                            .setCallback(() -> {
                                sidebarPanel.setAction(p1Action);
                                enableActions();
                            }))
                    .play();
        }
    };

    private void disableActions() {
        sidebarPanel.disableAction();
        bookshelf.disableAction();
        tagPhotoPanel.disableAction();
        
    }

    private void enableActions() {
        sidebarPanel.enableAction();
        bookshelf.enableAction();
        tagPhotoPanel.enableAction();
    }

    private final Runnable p5Action = new Runnable() {
        @Override
        public void run() {
            disableActions();

            panel.createTransition()
                    .push(new SLKeyframe(p1Cfg, 0.8f)
                            .setEndSide(SLSide.RIGHT, sidebarPanel)
                            .setCallback(() -> {
                                bookshelf.setAction(p5BackAction);
                                bookshelf.enableAction();
                            }))
                    .play();
        }
    };

    private final Runnable p5BackAction = new Runnable() {
        @Override
        public void run() {
            disableActions();

            panel.createTransition()
                    .push(new SLKeyframe(mainCfg, 0.8f)
                            .setStartSide(SLSide.LEFT, sidebarPanel)
                            .setCallback(() -> {
                                bookshelf.setAction(p5Action);
                                enableActions();
                            }))
                    .play();
        }
    };
    
    private final Runnable taggedPhotoAction = new Runnable() {
        @Override
        public void run() {
            disableActions();
            
                   panel.createTransition()
                    .push(new SLKeyframe(taggedPhotoConfig, 0.8f)
                            .setStartSide(SLSide.TOP, sidebarPanel,bookshelf)
                            .setCallback(() -> {
                                tagPhotoPanel.setAction(taggedPhotoBackAction);
                                enableActions();
                            }))
                    .play();
            
        }
    };
    
        private final Runnable taggedPhotoBackAction = new Runnable() {
        @Override
        public void run() {
            disableActions();
            
                   panel.createTransition()
                    .push(new SLKeyframe(mainCfg, 0.8f)
                            .setEndSide(SLSide.BOTTOM,tagPhotoPanel )
                            .setCallback(() -> {
                                tagPhotoPanel.setAction(taggedPhotoAction);
                                tagPhotoPanel.enableAction();
                            }))
                    .play();
            
        }
    };

//    Setup toolbar 
    private void setUpToolBar() {

        Image image = menu.getImage();
        Image newimg = image.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
        menu = new ImageIcon(newimg);
        
        Image addImage = addButton.getImage();
        Image scaleAddImage = addImage.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        addButton = new ImageIcon(scaleAddImage);
        
        JButton button = new JButton(menu);
        JButton button2 = new JButton(addButton);

        button.addActionListener((ActionEvent e) -> {
            if (isSideBarOnScreen) {
                hideSideBar();
                isSideBarOnScreen = false;
            } else {
                showSideBar();
                isSideBarOnScreen = true;
            }
        });
        
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new File(System.getProperty("user.dir")));
        
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            if (isTagBarOnScreen) {
                showTagMenu();
                isTagBarOnScreen = false;
                int valid = fc.showOpenDialog(CollectionFrame.this);
                if (valid == JFileChooser.APPROVE_OPTION) {
                    //System.out.println("Image Choosen");
                    File file = fc.getSelectedFile();

                    BufferedImage bImage = null;
                    try {
                            bImage = ImageIO.read(file);
                    } catch (IOException expect) {
                            System.out.println("Select valid image");
                            //exit(0);
                    }
                        
                    ImageIcon image = new ImageIcon(bImage);
                    list.add(image);
                    bookshelf.table.addImage(list, bookshelf.table);
                }
            } else {
                hideTagMenu();
                isTagBarOnScreen = true;
            }
              
            }
        });

        toolbar.setRollover(true);
        toolbar.add(button);
        toolbar.add(button2);
        toolbar.addSeparator();

        add(toolbar, BorderLayout.NORTH);

    }

    /*
    method used to showSideBar
     */
    private void showSideBar() {
        panel.createTransition()
                .push(new SLKeyframe(mainCfg, 0.6f)
                        .setCallback(() -> {
                            sidebarPanel.setAction(p5Action);
                            enableActions();
                        }))
                .play();

    }

    private void hideSideBar() {

        panel.createTransition()
                .push(new SLKeyframe(p1Cfg, 1f)
                        .setEndSide(SLSide.LEFT, sidebarPanel)
                        .setCallback(() -> {
                            sidebarPanel.setAction(p5BackAction);
                            sidebarPanel.enableAction();
                        }))
                .play();
    }
    
    
    private void showTagMenu(){
          disableActions();
                     panel.createTransition()
                    .push(new SLKeyframe(taggedPhotoConfig, 0.8f)
                            .setStartSide(SLSide.RIGHT, tagPhotoPanel)
                            .setDelay(0.6f, tagPhotoPanel)
                            .setCallback(() -> {
                                tagPhotoPanel.setAction(taggedPhotoBackAction);
                                tagPhotoPanel.enableAction();
                            }))
                    .play();
    }
    
    private void hideTagMenu(){
          panel.createTransition()
                    .push(new SLKeyframe(mainCfg, 0.8f)
                            .setEndSide(SLSide.BOTTOM,tagPhotoPanel )
                            .setCallback(() -> {
                                tagPhotoPanel.setAction(taggedPhotoAction);
                                tagPhotoPanel.enableAction();
                            }))
                    .play();
    }
    


}
