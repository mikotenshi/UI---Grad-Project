


import SlidingLibrary.SLAnimator;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * Created by newuser on 10/20/16.
 *
 */
public class SidebarPanel extends JPanel {

    JTextField textField = new JTextField("Search");

    private static final Color BG_COLOR = new Color(0x3B5998);
    private static final Color BORDER_COLOR = new Color(0x000000);
    private Runnable action;
    private boolean actionEnabled = true;
    private boolean hover = false;
    private int borderThickness = 2;
    private static final TweenManager tweenManager = SLAnimator.createTweenManager();
    private JButton importImageButton = new JButton("import");
    
    public SidebarPanel(){

        setSize(400,800);        
        setPreferredSize(new Dimension(200,800));
        setBackground(Color.LIGHT_GRAY);
        setLayout(new BorderLayout());
        
        add(textField, BorderLayout.NORTH);
        

    }
    public void setAction(Runnable action) {this.action = action;}
    public void enableAction() {actionEnabled = true; if (hover) showBorder();}
    public void disableAction() {actionEnabled = false;}

    private void showBorder() {
        tweenManager.killTarget(borderThickness);
        Tween.to(SidebarPanel.this, Accessor.BORDER_THICKNESS, 0.4f)
                .target(10)
                .start(tweenManager);
    }

    private void hideBorder() {
        tweenManager.killTarget(borderThickness);
        Tween.to(SidebarPanel.this, Accessor.BORDER_THICKNESS, 0.4f)
                .target(2)
                .start(tweenManager);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

    }
    
    
    // -------------------------------------------------------------------------
    // Tween Accessor
    // -------------------------------------------------------------------------

    public static class Accessor extends SLAnimator.ComponentAccessor {
        public static final int BORDER_THICKNESS = 100;

        @Override
        public int getValues(Component target, int tweenType, float[] returnValues) {
            SidebarPanel tp = (SidebarPanel) target;

            int ret = super.getValues(target, tweenType, returnValues);
            if (ret >= 0) return ret;

            switch (tweenType) {
                case BORDER_THICKNESS: returnValues[0] = tp.borderThickness; return 1;
                default: return -1;
            }
        }

        @Override
        public void setValues(Component target, int tweenType, float[] newValues) {
            SidebarPanel tp = (SidebarPanel) target;

            super.setValues(target, tweenType, newValues);

            switch (tweenType) {
                case BORDER_THICKNESS:
                    tp.borderThickness = Math.round(newValues[0]);
                    tp.repaint();
                    break;
            }
        }
    }
}
