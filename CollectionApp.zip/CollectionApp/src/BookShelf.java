
import SlidingLibrary.SLAnimator;
import SlidingLibrary.SLConfig;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


/**
 * This class represents our bookshelf
 * @author newuser
 */
public class BookShelf extends JPanel {

    
    private static final Color BG_COLOR = new Color(0x3B5998);
    private static final Color BORDER_COLOR = new Color(0x000000);
    private Runnable action;
    private boolean actionEnabled = true;
    private boolean hover = false;
    private int borderThickness = 2;
    private SLConfig mainConfig;
    private static final TweenManager tweenManager = SLAnimator.createTweenManager();
    public MyTable table = new MyTable();
    
    final BufferedImage image;
    ImageIcon image2 = new ImageIcon(getClass().getResource("/myimages/shelf.png"));

    public BookShelf() throws IOException {
        this.image = ImageIO.read(getClass().getResource("/myimages/shelf.png"));
        setBackground(BG_COLOR);
        setLayout(new BorderLayout());

        JScrollPane pane = new JScrollPane(table) {{
            setOpaque(false);
            getViewport().setOpaque(false);
        }
            protected void paintComponent(Graphics g) {                
                super.paintComponent(g);

                Dimension d = getSize();
                for (int x = 0; x < d.width; x += image2.getIconWidth()) {
                    for (int y = 0; y < d.height; y += image2.getIconHeight()) {
                        g.drawImage(image2.getImage(), x, y, null, null);
                   }
                }
            }
        };
        
        add(pane);
    }

   

    public void setAction(Runnable action) {
        this.action = action;
    }

    public void enableAction() {
        actionEnabled = true;
        if (hover) {
            showBorder();
        }
    }

    public void disableAction() {
        actionEnabled = false;
    }

    private void showBorder() {
        tweenManager.killTarget(borderThickness);
        Tween.to(BookShelf.this, Accessor.BORDER_THICKNESS, 0.4f)
                .target(10)
                .start(tweenManager);
    }

    private void hideBorder() {
        tweenManager.killTarget(borderThickness);
        Tween.to(BookShelf.this, Accessor.BORDER_THICKNESS, 0.4f)
                .target(2)
                .start(tweenManager);
    }

    public static class Accessor extends SLAnimator.ComponentAccessor {

        public static final int BORDER_THICKNESS = 100;

        @Override
        public int getValues(Component target, int tweenType, float[] returnValues) {
            BookShelf tp = (BookShelf) target;

            int ret = super.getValues(target, tweenType, returnValues);
            if (ret >= 0) {
                return ret;
            }

            switch (tweenType) {
                case BORDER_THICKNESS:
                    returnValues[0] = tp.borderThickness;
                    return 1;
                default:
                    return -1;
            }
        }

        @Override
        public void setValues(Component target, int tweenType, float[] newValues) {
            BookShelf tp = (BookShelf) target;

            super.setValues(target, tweenType, newValues);

            switch (tweenType) {
                case BORDER_THICKNESS:
                    tp.borderThickness = Math.round(newValues[0]);
                    tp.repaint();
                    break;
            }
        }
    }
}
