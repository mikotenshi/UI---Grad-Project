
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/*
* This class is the table that backs the bookshelf
*
*
 */

public class MyTable extends JTable {

    private ArrayList<Object> list;
    DefaultTableModel model;
    //JTable table;

    ImageIcon image = new ImageIcon(getClass().getResource("/myimages/shelf.png"));
    ImageIcon aboutIcon = new ImageIcon(getClass().getResource("/myimages/dexter.png"));
    ImageIcon addIcon = new ImageIcon(getClass().getResource("/myimages/powerpuff.jpg"));
    ImageIcon copyIcon = new ImageIcon(getClass().getResource("/myimages/dora.jpg"));

    Object[] data
            = {
                aboutIcon,
                addIcon,
                copyIcon,};
    
    public MyTable() {

        
        setOpaque(false);
        /*setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {{
            setOpaque(false);
        }});*/
        setShowGrid(false);
        setIntercellSpacing(new Dimension(0, 0));
        setRowHeight(200);
        setFillsViewportHeight(true);
        setTableHeader(null);


        configureModel();
    }

    public void configureModel() {
        list = new ArrayList<Object>();
        model = new DefaultTableModel();
        model.addColumn("1");
        model.addColumn("2");
        model.addColumn("3");
        model.addRow(data);

        setModel(model);
    }
 @Override
    public Class getColumnClass(int column) {
        return ImageIcon.class;
    }

    @Override
    public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
        Component c = super.prepareRenderer(renderer, row, column);
        // We want renderer component to be transparent
        // so background image is visible
        if (c instanceof JComponent) {
            ((JComponent) c).setOpaque(false);
        }
        return c;
    }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Dimension d = getSize();
//        for (int x = 0; x < d.width; x += image.getIconWidth()) {
//            for (int y = 0; y < d.height; y += image.getIconHeight()) {
//                g.drawImage(image.getImage(), x, y, null, null);
//            }
//        }

    }
    
    public void addImage(ArrayList<Object> list, MyTable table) {
        int i = 0;
        int counter = 0;
        Object[] data = new Object[3];
        System.out.println("here");
        while (i < list.size()) {
            //System.out.println("here");
            if (counter >= 3 || i == list.size() - 1) {
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                model.addRow(data);
                //System.out.println("added");
                data = new Object[3];
                
                i++;
                counter = 0;
            } else {
                data[counter] = list.get(i);
                i++;
                counter++;
            }
        }
        //table.invalidate();
        //table.fireTableDataChanged();
    }
}
